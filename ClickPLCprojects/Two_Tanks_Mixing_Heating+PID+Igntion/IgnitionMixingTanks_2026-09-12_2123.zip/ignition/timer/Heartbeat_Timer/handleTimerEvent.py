def handleTimerEvent():
    #logger = system.util.getLogger("Heartbeat")
    val = int(system.date.now().getTime() / 1000) % 30000
    result = system.tag.writeBlocking(["[default]Comms_HeartbeatCtr"], [val])
    #logger.info("wrote %d, quality %s" % (val, result[0]))